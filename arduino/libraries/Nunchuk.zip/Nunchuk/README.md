# Wii-Nunchuk

![Nunchuk](https://github.com/infusion/Fritzing/blob/master/Nunchuk/nunchuk.jpg?raw=true)

Schema
---

![screen](https://github.com/infusion/Fritzing/blob/master/Nunchuk/screen.png?raw=true)

Documentation
---
The full documentation can be found [here](http://www.xarg.org/2016/12/using-a-wii-nunchuk-with-arduino/).
